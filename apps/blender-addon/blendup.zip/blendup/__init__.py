bl_info = {
    "name": "BlendUp",
    "author": "BlendUp",
    "version": (0, 8, 2),
    "blender": (4, 2, 0),
    "location": "Vue 3D > Barre latérale > BlendUp",
    "description": "Gère les assets 3D BlendUp et les exports vers Godot ou Unity",
    "category": "Import-Export",
}

try:
    import bpy
except ModuleNotFoundError:  # Le cœur reste testable sans Blender.
    bpy = None

if bpy:
    from .handlers import register_handlers, unregister_handlers
    from .ops import CLASSES as OPERATOR_CLASSES
    from .prefs import BLENDUP_AddonPreferences
    from .ui import CLASSES as UI_CLASSES
    from .ui.library import CLASSES as LIBRARY_CLASSES, register_properties, unregister_properties
    CLASSES = (BLENDUP_AddonPreferences, *OPERATOR_CLASSES, *LIBRARY_CLASSES, *UI_CLASSES)
else:
    CLASSES = ()


def register():
    if not bpy:
        raise RuntimeError("BlendUp doit être chargé depuis Blender.")
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.blendup_validation_summary = bpy.props.StringProperty(default="")
    register_properties()
    from .ops.scene_asset_ops import register_scene_assets
    register_scene_assets()
    from .ops.bake_ops import BLENDUP_PG_bake
    bpy.types.Scene.blendup_bake = bpy.props.PointerProperty(type=BLENDUP_PG_bake)
    register_handlers()


def unregister():
    if not bpy:
        return
    unregister_handlers()
    from .ops.scene_asset_ops import unregister_scene_assets
    unregister_scene_assets()
    unregister_properties()
    if hasattr(bpy.types.Scene, "blendup_bake"):
        del bpy.types.Scene.blendup_bake
    if hasattr(bpy.types.WindowManager, "blendup_validation_summary"):
        del bpy.types.WindowManager.blendup_validation_summary
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
